<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="Forest Spirites - Testlevel" tilewidth="32" tileheight="32" tilecount="620" columns="20">
 <image source="../Tilesets/Tileset_Forest Spirites.png" width="640" height="992"/>
</tileset>
